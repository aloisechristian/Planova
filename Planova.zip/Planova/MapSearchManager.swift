import Foundation
import MapKit
import Combine

// Aggiungiamo NSObject e il delegate MKLocalSearchCompleterDelegate
class MapSearchManager: NSObject, ObservableObject, MKLocalSearchCompleterDelegate {
    @Published var foundPoints: [IntrestPoint] = []
    @Published var isSearching: Bool = false
    
    // MARK: - Autocompletamento
    @Published var searchResults: [MKLocalSearchCompletion] = []
    private var searchCompleter = MKLocalSearchCompleter()
    
    override init() {
        super.init()
        searchCompleter.delegate = self
        // Filtriamo per località per evitare che escano nomi di bar o ristoranti
        searchCompleter.resultTypes = .address
    }
    
    // Chiamata dalla UI ogni volta che il testo cambia
    func updateSearchQuery(_ query: String) {
        print("📝 Digitando: \(query)") // DEBUG
        if query.isEmpty {
            searchResults = []
        } else {
            searchCompleter.queryFragment = query
        }
    }
    
    // Delegate: Ricezione dei risultati
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        print("✅ Trovati \(completer.results.count) suggerimenti") // DEBUG
        DispatchQueue.main.async {
            self.searchResults = completer.results
        }
    }
    
    // Delegate: Gestione errori
    func completer(_ completer: MKLocalSearchCompleter, didFailWithError error: Error) {
        print("❌ Errore Autocompletamento: \(error.localizedDescription)") // DEBUG
    }
    
    // MARK: - Ricerca Punti di Interesse
    func searchPOIs(in city: String) {
        self.isSearching = true
        self.foundPoints = []
        
        let cleanCity = city.trimmingCharacters(in: .whitespacesAndNewlines)
        print("🗺️ 1. Cerco le coordinate per la città: \(cleanCity)")
        
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(cleanCity) { [weak self] placemarks, error in
            guard let self = self else { return }
            
            if let error = error {
                print("❌ Errore Geocoding: \(error.localizedDescription)")
                DispatchQueue.main.async { self.isSearching = false }
                return
            }
            
            guard let location = placemarks?.first?.location else {
                print("❌ Nessuna coordinata trovata")
                DispatchQueue.main.async { self.isSearching = false }
                return
            }
            
            print("✅ 2. Coordinate trovate per \(cleanCity)")
            
            let region = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 10000, longitudinalMeters: 10000)
            let request = MKLocalSearch.Request()
            request.naturalLanguageQuery = "Attractions"
            request.region = region
            
            let search = MKLocalSearch(request: request)
            search.start { response, error in
                DispatchQueue.main.async {
                    self.isSearching = false
                    if let response = response {
                        self.foundPoints = response.mapItems.map { mapItem in
                            IntrestPoint(
                                name: mapItem.name ?? "Uknown Location",
                                desc: mapItem.placemark.title,
                                timeOpening: "09:00",
                                timeClosing: "19:00",
                                price: 0.0,
                                coordinate: mapItem.placemark.coordinate
                            )
                        }
                    }
                }
            }
        }
    }
}
