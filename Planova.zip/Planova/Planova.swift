//
//  Planova.swift
//  Planova
//
//  Created by Foundation 15 on 06/03/26.
//
import SwiftUI

@main
struct PlanovaApp: App {
    // Inizializziamo il ViewModel qui
    @StateObject private var tripViewModel = TripViewModel()
    @StateObject private var mapSearchManager = MapSearchManager()
    
    var body: some Scene {
        WindowGroup {
            ContainerView()
                .environmentObject(tripViewModel) // Lo passiamo a tutta l'app
                .environmentObject(mapSearchManager)
        }
    }
}
