// Let you say the budget
import SwiftUI

struct BudgetSetupView: View {
    @State private var budget = ""
    @State private var goNext = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 40) {
            
            // Top Bar
            ZStack {
                Text("Budget").font(.system(size: 32, weight: .regular)).foregroundColor(.white)
                HStack {
                    Button(action: { dismiss() }) {
                        HStack(spacing: 4) {
                            Image(systemName: "chevron.left").font(.system(size: 16, weight: .semibold))
                            Text("Back").font(.system(size: 16, weight: .regular))
                        }
                        .padding(.horizontal, 14).padding(.vertical, 8)
                        .background(Color.white.opacity(0.4)).cornerRadius(20)
                        .foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.3))
                    }
                    Spacer()
                }
            }
            .padding(.horizontal, 20).padding(.top, 10)
            
            Spacer()
            
            VStack(spacing: 15) {
                Text("Enter your budget")
                    .font(.headline)
                    .foregroundColor(.white)
                
                TextField("€ 0", text: $budget)
                    .keyboardType(.decimalPad)
                    .font(.title)
                    .multilineTextAlignment(.center)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
            }
            .frame(width: 260, height: 140)
            .background(Color.white.opacity(0.3))
            .cornerRadius(20)
            
            Spacer()
            
            // Pulsante Next
            Button(action: { goNext = true }) {
                Text("Next")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundColor(Color(red: 0.20, green: 0.60, blue: 0.75))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .background(Color.white)
                    .cornerRadius(30)
            }
            .padding(.horizontal, 25).padding(.bottom, 30)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppBackground())
        .navigationDestination(isPresented: $goNext) {
            PointsListView()
                .navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    BudgetSetupView()
}
