// Budget view, let you add and sotract money


import SwiftUI

struct BudgetView: View {
    
    @State private var budget: Double = 100
    @State private var showInput = false
    @State private var amount = ""
    @State private var isAdding = true
    
    var body: some View {
        
        ZStack {
            
            VStack(spacing: 10) {
                Text("Your budget")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .padding(.top, 50)
                
                // Riquadro budget
                VStack {
                    Text("€\(budget, specifier: "%.2f")")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundStyle(Color.white)
                    
                }
                .frame(width: 260, height: 130)
                .background(.ultraThinMaterial) // sfondo semi trasparente
                .cornerRadius(15)
                .shadow(radius: 5)
                .padding(.top, 50)
                
                
                // Pulsante +
                Button(action: {
                    isAdding = true
                    showInput = true
                }) {
                    Text("Add to your budget")
                        .font(.system(size: 18, weight: .bold))
                }
                .frame(width: 250, height: 50)
                .background(Color.white) // Sfondo pieno
                .foregroundColor(Color(red: 0.20, green: 0.60, blue: 0.75)) // Testo azzurro
                .cornerRadius(25) // Arrotondamento coerente con il resto dell'app
                .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 4) // Leggera ombra


                // Pulsante -
                Button(action: {
                    isAdding = false
                    showInput = true
                }) {
                    Text("Delete from your budget")
                        .font(.system(size: 18, weight: .bold))
                }
                .frame(width: 250, height: 50)
                .background(Color.white)
                .foregroundColor(Color(red: 0.8, green: 0.3, blue: 0.3)) // Testo rossastro per indicare la sottrazione
                .cornerRadius(25)
                .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 4)
                
                Spacer()
            }
            
            
            // POPUP INPUT
            if showInput {
                
                Color.black.opacity(0.3)
                    .ignoresSafeArea()
                
                VStack(spacing: 20) {
                    
                    Text(isAdding ? "Add value" : "Delete value")
                        .font(.headline)
                    
                    TextField("Value", text: $amount)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(.roundedBorder)
                        .padding(.horizontal)
                    
                    Button("Confirm") {
                        
                        if let value = Double(amount) {
                            
                            if isAdding {
                                budget += value
                            } else {
                                budget -= value
                            }
                        }
                        
                        amount = ""
                        showInput = false
                    }
                    .padding()
                    .frame(width: 150)
                    .background(Color.blue.opacity(0.5))
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    
                }
                .frame(width: 250, height: 180)
                .background(.ultraThinMaterial) // trasparente
                .cornerRadius(20)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppBackground())
    }
}

#Preview {
    BudgetView()
}
