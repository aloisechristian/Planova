//
//  AppBackground.swift
//  Planova
//
//  Created by Foundation 15 on 06/03/26.
//
//Questo componente rappresenta lo sfondo di tutte le schermate dell'app
import SwiftUI

struct AppBackground: View {
    var body: some View {
        LinearGradient(
            gradient: Gradient(colors: [
                Color(red: 172/255, green: 179/255, blue: 255/255), // Lilla/Pervinca in alto (mantenuto)
                Color(red: 100/255, green: 160/255, blue: 240/255), // Azzurro più ricco e profondo
                Color(red: 110/255, green: 170/255, blue: 230/255)   // Un azzurro leggermente più luminoso in basso
            ]),
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea()
    }
}

#Preview {
    AppBackground()
}
