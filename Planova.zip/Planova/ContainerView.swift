//
//  ContainerView.swift
//  DemoPlanova
//
//  Created by Foundation 12 on 06/03/26.
//
import SwiftUI

struct ContainerView: View {
    // Rendiamo la TabBar trasparente per vedere lo sfondo che scivola sotto
    init() {
        let appearance = UITabBarAppearance()
        appearance.configureWithTransparentBackground()
        UITabBar.appearance().standardAppearance = appearance
        UITabBar.appearance().scrollEdgeAppearance = appearance
    }
    
    var body: some View {
        ZStack {
            AppBackground() // Lo sfondo base della TabView
            
            TabView {
                // TAB 1: Avvia il flusso di navigazione partendo dalla Home
                GradientCircleView()
                    .tabItem {
                        Label("Home", systemImage: "house")
                    }
                
                // TAB 2: Permette di andare diretto al Plan
                PlanHistoryView()
                    .tabItem {
                        Label("Trips", systemImage: "calendar")
                    }
                
                // TAB 3: Budget
                BudgetView()
                    .tabItem {
                        Label("Budget", systemImage: "eurosign.circle")
                    }
            }
            .tint(.accentColor) // Colore icona selezionata
        }
    }
}

#Preview {
    ContainerView()
        .environmentObject(TripViewModel())
}
