//
//  WikipediaResponse.swift
//  Planova
//
//  Created by Foundation 15 on 10/03/26.
//
import Foundation

struct WikipediaResponse: Codable {
    let extract: String
    let thumbnail: Thumbnail?
    let content_urls: ContentUrls
    
    struct Thumbnail: Codable {
        let source: String
    }
    
    struct ContentUrls: Codable {
        let mobile: Mobile
        
        struct Mobile: Codable {
            let page: String
        }
    }
}
