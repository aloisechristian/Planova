import SwiftUI
import MapKit

// MARK: - Cella del Singolo Giorno
struct DayCell: View {
    let date: Date?
    let startDate: Date?
    let endDate: Date?
    let action: () -> Void
    
    var isStart: Bool {
        guard let d = date, let s = startDate else { return false }
        return Calendar.current.isDate(d, inSameDayAs: s)
    }
    
    var isEnd: Bool {
        guard let d = date, let e = endDate else { return false }
        return Calendar.current.isDate(d, inSameDayAs: e)
    }
    
    var isMiddle: Bool {
        guard let d = date, let s = startDate, let e = endDate else { return false }
        let dayStart = Calendar.current.startOfDay(for: d)
        let sStart = Calendar.current.startOfDay(for: s)
        let eStart = Calendar.current.startOfDay(for: e)
        return dayStart > sStart && dayStart < eStart
    }
    
    var body: some View {
        ZStack {
            if let d = date {
                if isMiddle {
                    Rectangle().fill(Color.purple.opacity(0.15))
                } else if isStart && endDate != nil {
                    HStack(spacing: 0) { Color.clear; Color.purple.opacity(0.15) }
                } else if isEnd && startDate != nil {
                    HStack(spacing: 0) { Color.purple.opacity(0.15); Color.clear }
                }
                
                if isStart || isEnd {
                    Circle().fill(Color(red: 0.6, green: 0.2, blue: 0.8)).frame(width: 32, height: 32)
                }
                
                Text("\(Calendar.current.component(.day, from: d))")
                    .font(.system(size: 15, weight: isStart || isEnd ? .bold : .regular))
                    .foregroundColor(isStart || isEnd ? .white : .black.opacity(0.8))
            } else {
                Color.clear
            }
        }
        .frame(height: 40)
        .contentShape(Rectangle())
        .onTapGesture { if date != nil { action() } }
    }
}

// MARK: - Calendario Dinamico
struct CustomRangeCalendar: View {
    @State private var currentMonth: Date = Date()
    @Binding var startDate: Date?
    @Binding var endDate: Date?
    @State private var showDatePicker = false
    
    let columns = Array(repeating: GridItem(.flexible(), spacing: 0), count: 7)
    let weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    
    var body: some View {
        VStack(spacing: 15) {
            HStack {
                Button(action: { changeMonth(by: -1) }) { Image(systemName: "chevron.left").font(.system(size: 14, weight: .semibold)).foregroundColor(.black).padding(5) }
                Spacer()
                Button(action: { showDatePicker = true }) { Text(monthYearString(for: currentMonth)).font(.system(size: 16, weight: .medium)).foregroundColor(.black) }
                Spacer()
                Button(action: { changeMonth(by: 1) }) { Image(systemName: "chevron.right").font(.system(size: 14, weight: .semibold)).foregroundColor(.black).padding(5) }
            }
            .padding(.horizontal, 10).padding(.top, 5).padding(.bottom, 10)
            
            HStack {
                ForEach(weekDays, id: \.self) { day in Text(day).font(.system(size: 12, weight: .medium)).foregroundColor(Color.gray.opacity(0.5)).frame(maxWidth: .infinity) }
            }
            
            LazyVGrid(columns: columns, spacing: 8) {
                let days = daysInCurrentMonth()
                ForEach(0..<days.count, id: \.self) { index in
                    DayCell(date: days[index], startDate: startDate, endDate: endDate) {
                        if let date = days[index] { handleTap(on: date) }
                    }
                }
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: .black.opacity(0.15), radius: 15, x: 0, y: 8)
        .padding(.horizontal, 25)
        .sheet(isPresented: $showDatePicker) {
            VStack(spacing: 20) {
                Text("Jump to date").font(.headline).padding(.top, 20)
                DatePicker("", selection: $currentMonth, displayedComponents: [.date]).datePickerStyle(.wheel).labelsHidden()
                Button(action: { showDatePicker = false }) {
                    Text("Done").font(.system(size: 18, weight: .bold)).foregroundColor(.white).frame(width: 200, height: 50).background(Color(red: 0.20, green: 0.60, blue: 0.75)).cornerRadius(25)
                }.padding(.bottom, 20)
            }
            .presentationDetents([.height(350)])
        }
    }
    
    func changeMonth(by value: Int) { if let newMonth = Calendar.current.date(byAdding: .month, value: value, to: currentMonth) { currentMonth = newMonth } }
    func monthYearString(for date: Date) -> String { let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US"); formatter.dateFormat = "MMMM yyyy"; return formatter.string(from: date) }
    func daysInCurrentMonth() -> [Date?] {
        var calendar = Calendar.current; calendar.firstWeekday = 2
        let components = calendar.dateComponents([.year, .month], from: currentMonth)
        guard let firstDay = calendar.date(from: components), let range = calendar.range(of: .day, in: .month, for: firstDay) else { return [] }
        let weekday = calendar.component(.weekday, from: firstDay)
        let offset = (weekday >= 2) ? weekday - 2 : 6
        var days: [Date?] = Array(repeating: nil, count: offset)
        for i in 0..<range.count { if let date = calendar.date(byAdding: .day, value: i, to: firstDay) { days.append(date) } }
        return days
    }
    func handleTap(on date: Date) {
        let selectedDate = Calendar.current.startOfDay(for: date)
        if startDate == nil { startDate = selectedDate } else if let start = startDate, endDate == nil { if selectedDate > start { endDate = selectedDate } else { startDate = selectedDate } } else { startDate = selectedDate; endDate = nil }
    }
}

// MARK: - Schermata Principale
struct DestinationView: View {
    @EnvironmentObject var tripViewModel: TripViewModel
    @EnvironmentObject var mapSearchManager: MapSearchManager
    
    @State private var destination = ""
    @State private var isSelecting = false
    @State private var startDate: Date? = nil
    @State private var endDate: Date? = nil
    @State private var goNext = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        // ZStack Radice: Isola lo sfondo dall'interfaccia
        ZStack {
            
            // Lo sfondo va a tutto schermo (coprendo anche la tacca in alto)
            AppBackground()
                .ignoresSafeArea(.all)
            
            // Il GeometryReader è LA soluzione. Legge le dimensioni pulite dello schermo...
            GeometryReader { geo in
                
                VStack(spacing: 0) {
                    
                    // MARK: - TOP BAR
                    ZStack {
                        Text("Destination").font(.system(size: 32, weight: .regular)).foregroundColor(.white)
                        HStack {
                            Button(action: { dismiss() }) {
                                HStack(spacing: 4) { Image(systemName: "chevron.left").font(.system(size: 16, weight: .semibold)); Text("Back").font(.system(size: 16, weight: .regular)) }
                                    .padding(.horizontal, 14).padding(.vertical, 8).background(Color.white.opacity(0.4)).cornerRadius(20).foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.3))
                            }
                            Spacer()
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    
                    Spacer().frame(height: 35)
                    
                    // MARK: - ZSTACK INTERNO (Ricerca vs Calendario)
                    ZStack(alignment: .top) {
                        
                        // --- LAYER 0: CALENDARIO E BOTTONE NEXT ---
                        VStack(spacing: 0) {
                            Spacer().frame(height: 70) // Lascia lo spazio esatto per la Search Bar
                            
                            Text("Choose your date").font(.system(size: 24, weight: .bold)).foregroundColor(.white).padding(.bottom, 20)
                            
                            CustomRangeCalendar(startDate: $startDate, endDate: $endDate)
                            
                            Spacer()
                            
                            Button(action: {
                                tripViewModel.destination = destination
                                tripViewModel.startDate = startDate
                                tripViewModel.endDate = endDate
                                mapSearchManager.searchPOIs(in: destination)
                                goNext = true
                            }) {
                                Text("Next").font(.system(size: 18, weight: .bold)).foregroundColor(Color(red: 0.20, green: 0.60, blue: 0.75)).frame(maxWidth: .infinity).padding(.vertical, 16).background(Color.white).cornerRadius(30).shadow(color: .black.opacity(0.15), radius: 10, x: 0, y: 5)
                            }
                            .padding(.horizontal, 25).padding(.bottom, 30)
                        }
                        .zIndex(0)
                        
                        // --- LAYER 1: SEARCH BAR E TENDINA SUGGERIMENTI ---
                        VStack(spacing: 5) {
                            
                            HStack {
                                Image(systemName: "magnifyingglass").foregroundColor(Color(red: 0.2, green: 0.3, blue: 0.5))
                                
                                TextField("Select your destination", text: $destination)
                                    .foregroundColor(.black)
                                    .onChange(of: destination) { newValue in
                                        if isSelecting {
                                            isSelecting = false
                                        } else {
                                            mapSearchManager.updateSearchQuery(newValue)
                                        }
                                    }
                                
                            }
                            .padding(.horizontal, 16)
                            .padding(.vertical, 14)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(25)
                            .overlay(RoundedRectangle(cornerRadius: 25).stroke(Color.white.opacity(0.5), lineWidth: 1))
                            .shadow(color: .black.opacity(0.05), radius: 5, x: 0, y: 5)
                            .padding(.horizontal, 25)
                            
                            // Tendina Autocompletamento
                            if !mapSearchManager.searchResults.isEmpty {
                                ScrollView {
                                    VStack(alignment: .leading, spacing: 0) {
                                        ForEach(mapSearchManager.searchResults, id: \.self) { result in
                                            Button(action: {
                                                isSelecting = true // Blocca la ricerca
                                                destination = result.subtitle.isEmpty ? result.title : "\(result.title), \(result.subtitle)"
                                                mapSearchManager.searchResults = []
                                                
                                                // Chiude la tastiera
                                                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                                            }) {
                                                VStack(alignment: .leading, spacing: 4) {
                                                    Text(result.title)
                                                        .font(.system(size: 16, weight: .semibold))
                                                        .foregroundColor(.black)
                                                    
                                                    if !result.subtitle.isEmpty {
                                                        Text(result.subtitle)
                                                            .font(.system(size: 14))
                                                            .foregroundColor(.gray)
                                                    }
                                                }
                                                .padding(.vertical, 12)
                                                .padding(.horizontal, 16)
                                                .frame(maxWidth: .infinity, alignment: .leading)
                                            }
                                            Divider()
                                        }
                                    }
                                }
                                .background(Color.white.opacity(0.95))
                                .cornerRadius(15)
                                .shadow(color: .black.opacity(0.2), radius: 10, x: 0, y: 5)
                                .frame(maxHeight: 220)
                                .padding(.horizontal, 35)
                            }
                        }
                        .zIndex(1)
                    }
                }
                // ...e qui ingabbiamo il VStack in modo che occupi ESATTAMENTE lo spazio disponibile,
                // ignorando qualsiasi tentativo della tastiera di rimpicciolirlo.
                .frame(width: geo.size.width, height: geo.size.height, alignment: .top)
            }
            // 🌟 IL TOCCO MAGICO: Diciamo al GeometryReader di ignorare la tastiera!
            .ignoresSafeArea(.keyboard)
        }
        .onTapGesture {
            mapSearchManager.searchResults = []
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        }
        .navigationDestination(isPresented: $goNext) {
            BudgetSetupView().navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    DestinationView()
        .environmentObject(TripViewModel())
        .environmentObject(MapSearchManager())
}
