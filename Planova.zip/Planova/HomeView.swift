//
//  HomeView.swift
//  Planova
//
//  Created by Foundation 15 on 06/03/26.
//
import SwiftUI

// (Color extension e PressableCircleStyle rimangono uguali...)
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (255, 255, 255, 255)
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue:  Double(b) / 255, opacity: Double(a) / 255)
    }
}

struct PressableCircleStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.88 : 1.0)
            .opacity(configuration.isPressed ? 0.9 : 1.0)
            .animation(.spring(response: 0.3, dampingFraction: 0.6), value: configuration.isPressed)
    }
}

struct GradientCircleView: View {
    @EnvironmentObject var tripViewModel: TripViewModel // <--- Aggiungiamo l'accesso al ViewModel
    @State private var goNext = false
    @State private var goTestSummary = false // <--- Stato per la rotta di test
    
    let bgColor = Color(hex: "7B61FF")
    let circleColor = Color(hex: "A1ACFA")
    
    var body: some View {
        NavigationStack {
            ZStack {
                AppBackground() // Sfondo globale
                
                VStack {
                    Text("Home")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .padding(.top, 50)
                    
                    Spacer()
                    
                    // Bottone Originale
                    Button(action: { goNext = true }) {
                        Circle()
                            .fill(LinearGradient(colors: [circleColor, .white.opacity(0.8)], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .frame(width: 250, height: 250)
                            .shadow(color: .black.opacity(0.2), radius: 20, x: 0, y: 15)
                            .overlay(
                                Text("Start planning...")
                                    .font(.title2.bold())
                                    // 👇 Modificato: Colore blu scuro per contrastare con il cerchio chiaro
                                    .foregroundColor(Color(red: 0.2, green: 0.3, blue: 0.5))
                            )
                    }
                    .buttonStyle(PressableCircleStyle())
                    
                    Spacer()
                    
                    // MARK: - BOTTONE DI TEST RAPIDO (Da rimuovere prima di pubblicare l'app)
                    Button(action: {
                        // 1. Inseriamo dati finti ma realistici
                        tripViewModel.destination = "Parigi"
                        tripViewModel.startDate = Date() // Oggi
                        tripViewModel.endDate = Calendar.current.date(byAdding: .day, value: 3, to: Date()) // Tra 3 giorni
                        
                        // Creiamo un paio di attrazioni finte
                        tripViewModel.selectedPoints = [
                            IntrestPoint(name: "Torre Eiffel", desc: "Il simbolo di Parigi", timeOpening: "09:00", timeClosing: "23:00"),
                            IntrestPoint(name: "Museo del Louvre", desc: "Museo d'arte", timeOpening: "09:00", timeClosing: "18:00"),
                            IntrestPoint(name: "Cattedrale di Notre-Dame", desc: "Cattedrale storica", timeOpening: "08:00", timeClosing: "18:45")
                        ]
                        
                        // 2. Saltiamo direttamente al Summary
                        goTestSummary = true
                    }) {
                        /*HStack {
                         Image(systemName: "bolt.fill")
                         Text("Fast Test Gemini API")
                         }
                         .font(.headline)
                         .foregroundColor(.white)
                         .padding()
                         .background(Color.orange.opacity(0.8))
                         .cornerRadius(15)*/
                    }
                    .padding(.bottom, 30)
                }
            }
            .navigationDestination(isPresented: $goNext) {
                DestinationView()
                    .navigationBarBackButtonHidden(true)
            }
            // Aggiungiamo la navigazione per il bottone di test
            .navigationDestination(isPresented: $goTestSummary) {
                Summary()
                    .navigationBarBackButtonHidden(true)
            }
        }
    }
}

#Preview {
    GradientCircleView()
        .environmentObject(TripViewModel())
}
