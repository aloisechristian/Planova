//
//  ContentView.swift
//  planova
//
//  Created by Foundation 11 on 06/03/26.
//

import SwiftUI
import SwiftUI

struct ContentView: View {
    
    @State private var rotate = false
    
    var body: some View {
        VStack {
            /*Text("Planova")
             .font(.largeTitle)
             .foregroundColor(.white)
             .bold()*/
            
            Spacer()
            
            ZStack {
                
                Circle()
                    .stroke(Color.white.opacity(0.3), lineWidth: 8)
                    .frame(width: 200, height: 200)
                
                Circle()
                    .trim(from: 0, to: 0.25)
                    .stroke(Color.white, lineWidth: 8)
                    .frame(width: 200, height: 200)
                    .rotationEffect(.degrees(rotate ? 360 : 0))
                    .animation(.linear(duration: 1).repeatForever(autoreverses: false), value: rotate)
                
                Text("Loading...")
                    .foregroundColor(.white)
                    .font(.title)
                
            }
            .onAppear {
                rotate = true
            }
            
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(AppBackground())
    }
}

#Preview {
    ContentView()
}
