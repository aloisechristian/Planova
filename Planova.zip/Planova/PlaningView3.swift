// suggest the attraction
import SwiftUI
import MapKit

// MARK: - Modello Aggiornato
struct IntrestPoint: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let desc: String?
    let timeOpening: String
    let timeClosing: String
    var price: Double? = nil
    var coordinate: CLLocationCoordinate2D? = nil
    
    static func == (lhs: IntrestPoint, rhs: IntrestPoint) -> Bool {
        return lhs.id == rhs.id
    }
}

// MARK: - Cella Singola Attrazione
struct IntrestPointRow: View {
    let point: IntrestPoint
    @Binding var pointToShowDetails: IntrestPoint? // <--- Gestisce l'apertura del dettaglio
    let isSelected: Bool // <--- NUOVO: indica se è stato scelto
    let onToggle: () -> Void // <--- MODIFICATO: per gestire aggiunta/rimozione
    
    @EnvironmentObject var tripViewModel: TripViewModel
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                // Toccando il nome o l'icona info, apriamo Wikipedia
                Button(action: {
                    pointToShowDetails = point
                }) {
                    HStack(spacing: 6) {
                        Text(point.name)
                            .font(.headline)
                            .foregroundColor(.primary)
                        Image(systemName: "info.circle")
                            .font(.subheadline)
                            .foregroundColor(.blue)
                    }
                }
                .buttonStyle(.plain)
                
                Spacer()
                
                // BOTTONE +/- DINAMICO
                Button(action: onToggle) {
                    Image(systemName: isSelected ? "checkmark.circle.fill" : "plus.circle.fill")
                        .font(.title2)
                        .foregroundColor(isSelected ? .green : .blue)
                }
                .buttonStyle(.plain)
            }
            
            // Orari e prezzi sempre visibili
            HStack {
                Text("Hours: \(point.timeOpening)-\(point.timeClosing)")
                Spacer()
                
                if let price = tripViewModel.attractionPrices[point.name] {
                    Text(price)
                        .fontWeight(.medium)
                        .foregroundColor(price == "Costs not available" ? .red : .green)
                } else {
                    ProgressView().scaleEffect(0.7)
                }
            }
            .font(.caption)
            .foregroundColor(.gray)
            .padding(.top, 4)
        }
        .padding(.vertical, 8)
    }
}

// MARK: - Lista Attrazioni (PlaningView3)
struct PointsListView: View {
    @EnvironmentObject var tripViewModel: TripViewModel
    @EnvironmentObject var mapSearchManager: MapSearchManager
    
    @State private var selectedPoints: [IntrestPoint] = []
    
    @State private var goNext = false
    @State private var pointToShowDetails: IntrestPoint? = nil // <--- Stato per la vista Wiki
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // TOP BAR
            ZStack {
                Text("Attractions").font(.system(size: 32, weight: .regular)).foregroundColor(.white)
                HStack {
                    Button(action: { dismiss() }) {
                        HStack(spacing: 4) { Image(systemName: "chevron.left").font(.system(size: 16, weight: .semibold)); Text("Back").font(.system(size: 16, weight: .regular)) }
                            .padding(.horizontal, 14).padding(.vertical, 8).background(Color.white.opacity(0.4)).cornerRadius(20).foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.3))
                    }
                    Spacer()
                }
            }.padding(.horizontal, 20).padding(.top, 10).padding(.bottom, 20)
            
            // CONTENUTO CENTRALE: Caricamento o Lista
            if mapSearchManager.isSearching {
                Spacer()
                ProgressView("Searching for attractions...")
                    .tint(.white)
                    .foregroundColor(.white)
                Spacer()
            } else {
                List {
                    ForEach(mapSearchManager.foundPoints) { point in
                        // Controlla se il punto è attualmente tra quelli selezionati
                        let isSelected = selectedPoints.contains(where: { $0.id == point.id })
                        
                        IntrestPointRow(
                            point: point,
                            pointToShowDetails: $pointToShowDetails,
                            isSelected: isSelected, // <--- Passiamo lo stato
                            onToggle: {
                                // Aggiunge o Rimuove dalla lista
                                if isSelected {
                                    selectedPoints.removeAll(where: { $0.id == point.id })
                                } else {
                                    selectedPoints.append(point)
                                }
                            }
                        )
                    }
                }
                .scrollContentBackground(.hidden)
                .task {
                    if !mapSearchManager.foundPoints.isEmpty {
                        let targetDest = tripViewModel.destination.isEmpty ? "Roma" : tripViewModel.destination
                        await tripViewModel.fetchAllPrices(for: mapSearchManager.foundPoints, destination: targetDest)
                    }
                }
            }
            
            // PULSANTE NEXT
            Button(action: {
                tripViewModel.selectedPoints = selectedPoints
                goNext = true
            }) {
                Text("Next: Summary").font(.system(size: 18, weight: .bold)).foregroundColor(Color(red: 0.20, green: 0.60, blue: 0.75)).frame(maxWidth: .infinity).padding(.vertical, 16).background(Color.white).cornerRadius(30)
            }.padding(.horizontal, 25).padding(.bottom, 30).padding(.top, 10)
        }
        .background(AppBackground())
        .navigationDestination(isPresented: $goNext) {
            Summary().navigationBarBackButtonHidden(true)
        }
        // GESTIONE DEL FOGLIO WIKIPEDIA
        .sheet(item: $pointToShowDetails) { point in
            WikipediaDetailView(point: point, city: tripViewModel.destination)
        }
        .task {
            let targetDest = tripViewModel.destination.isEmpty ? "Roma" : tripViewModel.destination
            mapSearchManager.searchPOIs(in: targetDest)
        }
        .onChange(of: mapSearchManager.foundPoints) { newPoints in
            if !newPoints.isEmpty {
                Task {
                    let targetDest = tripViewModel.destination.isEmpty ? "Roma" : tripViewModel.destination
                    await tripViewModel.fetchAllPrices(for: newPoints, destination: targetDest)
                }
            }
        }
    }
}

/*#Preview {
 PointsListView(selectedPoints: .constant([]))
 .environmentObject(TripViewModel())
 }
 Commentato per non far partire sempre le chiamate a gemini
 */
