//
//  WikipediaDetailView.swift
//  Planova
//
//  Created by Foundation 15 on 10/03/26.
//
import SwiftUI

struct WikipediaDetailView: View {
    let point: IntrestPoint
    let city: String
    @State private var wikiData: WikipediaResponse?
    @State private var isLoading = true
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    
                    if isLoading {
                        VStack {
                            Spacer().frame(height: 100)
                            ProgressView("Searching Wikipedia...")
                                .frame(maxWidth: .infinity)
                        }
                    } else if let data = wikiData {
                        
                        // Immagine con vincoli di dimensione corretti
                        if let imageUrl = data.thumbnail?.source {
                            AsyncImage(url: URL(string: imageUrl)) { phase in
                                switch phase {
                                case .empty:
                                    Rectangle()
                                        .fill(Color(UIColor.secondarySystemBackground))
                                        .overlay(ProgressView())
                                        .frame(height: 250)
                                case .success(let image):
                                    image
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(maxWidth: .infinity, minHeight: 250, maxHeight: 250)
                                        .clipped()
                                case .failure(_):
                                    EmptyView()
                                @unknown default:
                                    EmptyView()
                                }
                            }
                            .cornerRadius(16)
                            .shadow(color: .black.opacity(0.1), radius: 5, x: 0, y: 4)
                        }
                        
                        VStack(alignment: .leading, spacing: 12) {
                            Text("About")
                                .font(.title2)
                                .fontWeight(.semibold)
                                .foregroundColor(.primary)
                            
                            Text(data.extract)
                                .font(.body)
                                .foregroundColor(.secondary)
                                .lineSpacing(6)
                                .fixedSize(horizontal: false, vertical: true) // Forza l'andata a capo corretta
                        }
                        
                        Link(destination: URL(string: data.content_urls.mobile.page)!) {
                            HStack {
                                Image(systemName: "safari")
                                Text("Read full article")
                                    .fontWeight(.semibold)
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(12)
                        }
                        .padding(.top, 10)
                        
                        // 👇 NUOVO CREDITO WIKIPEDIA
                        Text("Text and images courtesy of Wikipedia, licensed under CC BY-SA.")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                            .padding(.top, 4)
                        // 👆 FINE CREDITO
                        
                    } else {
                        // Stato di errore / Non trovato
                        VStack(spacing: 12) {
                            Spacer().frame(height: 80)
                            Image(systemName: "doc.text.magnifyingglass")
                                .font(.system(size: 40))
                                .foregroundColor(.gray)
                            
                            Text("No information available on Wikipedia for this location.")
                                .font(.body)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                    }
                }
                .padding(.horizontal, 20) // Padding applicato correttamente ai lati
                .padding(.bottom, 30)
                .padding(.top, 10)
            }
            .navigationTitle(point.name)
            .navigationBarTitleDisplayMode(.large)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: { dismiss() }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(Color(UIColor.tertiaryLabel))
                            .font(.system(size: 24))
                    }
                }
            }
        }
        .task {
            do {
                wikiData = try await WikipediaService.fetchDetails(for: point.name, in: city)
                isLoading = false
            } catch {
                print("Wikipedia Error: \(error)")
                isLoading = false
            }
        }
    }
}
