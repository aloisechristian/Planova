//
//  PlanHistoryView.swift
//  Planova
//
//  Created by Foundation 15 on 09/03/26.
//
import SwiftUI

struct PlanHistoryView: View {
    @EnvironmentObject var tripViewModel: TripViewModel
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Sfondo che copre tutta la vista
                AppBackground()
                    .ignoresSafeArea()
                
                VStack(spacing: 0) {
                    Text("Trips")
                        .font(.system(size: 32))
                        .foregroundColor(.white)
                        .padding(.top, 50)
                        .padding(.bottom, 20)
                    
                    if tripViewModel.savedTrips.isEmpty {
                        // STATO VUOTO: Nessun viaggio organizzato
                        Spacer()
                        VStack(spacing: 20) {
                            Image(systemName: "airplane.departure")
                                .font(.system(size: 70))
                                .foregroundColor(.white.opacity(0.8))
                            
                            Text("You haven't planned\nany trip yet.")
                                .font(.title3)
                                .fontWeight(.medium)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 40)
                        }
                        Spacer()
                        Spacer()
                    } else {
                        // LISTA DEI VIAGGI SALVATI
                        List {
                            ForEach(tripViewModel.savedTrips) { trip in
                                // NavigationLink per aprire i dettagli del viaggio cliccato
                                NavigationLink(destination: SavedTripDetailView(trip: trip)) {
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text(trip.destination.isEmpty ? "Uknown destination" : trip.destination)
                                            .font(.title3)
                                            .fontWeight(.bold)
                                            .foregroundColor(.primary)
                                        
                                        Text("\(trip.itinerary.count) days planned")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    .padding(.vertical, 8)
                                }
                                .listRowBackground(Color.white.opacity(0.85)) // Migliora la leggibilità sulla cella
                            }
                            .onDelete(perform: tripViewModel.deleteTrip)
                        }
                        .scrollContentBackground(.hidden)
                    }
                }
            }
        }
    }
}

// MARK: - Nuova vista per visualizzare i dettagli del viaggio salvato
struct SavedTripDetailView: View {
    let trip: SavedTrip
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        ZStack {
            AppBackground()
                .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // TOP BAR
                ZStack {
                    Text(trip.destination.isEmpty ? "Trip Plan" : trip.destination)
                        .font(.system(size: 32, weight: .regular))
                        .foregroundColor(.white)
                    
                    HStack {
                        Button(action: { dismiss() }) {
                            HStack(spacing: 4) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 16, weight: .semibold))
                                Text("Back")
                                    .font(.system(size: 16, weight: .regular))
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.4))
                            .cornerRadius(20)
                            .foregroundColor(Color(red: 0.1, green: 0.1, blue: 0.3))
                        }
                        Spacer()
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 10)
                .padding(.bottom, 20)
                
                // ITINERARIO (Riutilizza graficamente DayCardView da Summary.swift)
                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(trip.itinerary) { day in
                            DayCardView(day: day)
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 100)
                }
            }
        }
        .navigationBarBackButtonHidden(true) // Nascondiamo la barra nativa per usare la nostra Custom
    }
}

#Preview {
    PlanHistoryView()
        .environmentObject(TripViewModel())
}
