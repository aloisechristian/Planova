⚙️ Setup and Installation

This app uses the Google Gemini API. Since the API key is sensitive data, it is not included in this repository. To run the app locally, you will need to generate your own key and set up a specific file by following these steps:

Clone or download this repository to your Mac.

Open the project in Xcode.

Click on File > New > File... (or press Cmd + N).

Search for Property List and select it.

Save the file naming it EXACTLY Secrets.plist (make sure to add it to the main app target, Planova).

Open the newly created Secrets.plist file. Click the + button to add a new row and configure it as follows:

Key: API_KEY

Type: String

Value: Paste your Google Gemini API key here.

Now you can select the simulator (or your physical device) and run the app with Cmd + R.

Note: The Secrets.plist file is already included in the .gitignore, so you won't risk accidentally uploading your personal key if you decide to make changes and push a commit.
