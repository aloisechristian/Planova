import SwiftUI
import Combine
import Foundation

// MARK: - Strutture Dati per il JSON
struct ItineraryDay: Codable, Identifiable {
    var id = UUID()
    let dateInfo: String // es. "Lunedì 1 Gennaio"
    let activities: [Activity]
    
    enum CodingKeys: String, CodingKey {
        case dateInfo = "data"
        case activities = "attivita"
    }
}

struct Activity: Codable, Identifiable {
    var id = UUID()
    let time: String // es. "Mattina", "10:00 - 12:00"
    let place: String // es. "Fontana di Trevi"
    let description: String // Una breve descrizione
    
    enum CodingKeys: String, CodingKey {
        case time = "orario"
        case place = "luogo"
        case description = "descrizione"
    }
}

// Aggiunto il protocollo Codable e var invece di let per id
struct SavedTrip: Identifiable, Codable {
    var id = UUID()
    let destination: String
    let startDate: Date?
    let endDate: Date?
    let itinerary: [ItineraryDay]
}

// MARK: - ViewModel
@MainActor
class TripViewModel: ObservableObject {
    
    // MARK: - Dati base del viaggio
    @Published var destination: String = ""
    @Published var startDate: Date? = nil
    @Published var endDate: Date? = nil
    @Published var selectedPoints: [IntrestPoint] = []
    @Published var availablePoints: [IntrestPoint] = []
    
    // MARK: - Dati generati dall'IA
    @Published var itineraryDays: [ItineraryDay] = []
    @Published var attractionPrices: [String: String] = [:] // Dizionario: [Nome Attrazione : Prezzo]
    
    // MARK: - Stati della UI
    @Published var isLoading: Bool = false
    @Published var errorMessage: String? = nil
    
    // MARK: - Configurazione API e Modelli
    // Recupera la chiave api da file Secrets.plist
    private var apiKey: String {
        guard let filePath = Bundle.main.path(forResource: "Secrets", ofType: "plist"),
              let plist = NSDictionary(contentsOfFile: filePath),
              let value = plist["API_KEY"] as? String else {
            fatalError("⚠️ Impossibile trovare API_KEY nel file Secrets.plist. Assicurati che il file esista e contenga la chiave corretta.")
        }
        return value
    }
    
    // Modelli scelti per ottimizzare le chiamate API
    private let itineraryModel = "gemini-3.1-flash-lite-preview" // Per la generazione dell'itinerario (illimitato/economico)
    private let pricingModel = "gemini-2.5-flash"              // Solo per i prezzi con Search Grounding (limite 20 RPD)
    
    @Published var savedTrips: [SavedTrip] = []
    
    // MARK: - Salvataggio Persistente
    private let saveKey = "SavedTripsData"
    
    init() {
        loadTrips() // Carica i dati salvati all'avvio
    }
    
    private func saveTripsToDevice() {
        do {
            let encoded = try JSONEncoder().encode(savedTrips)
            UserDefaults.standard.set(encoded, forKey: saveKey)
        } catch {
            print("Errore nel salvataggio dei viaggi: \(error.localizedDescription)")
        }
    }
    
    private func loadTrips() {
        if let savedData = UserDefaults.standard.data(forKey: saveKey) {
            do {
                let decoded = try JSONDecoder().decode([SavedTrip].self, from: savedData)
                self.savedTrips = decoded
            } catch {
                print("Errore nel caricamento dei viaggi: \(error.localizedDescription)")
            }
        }
    }
    
    // MARK: - Generazione Itinerario
    func generateItinerary() async {
        self.isLoading = true
        self.errorMessage = nil
        self.itineraryDays = []
        
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        let startStr = startDate != nil ? formatter.string(from: startDate!) : "Date not defined"
        let endStr = endDate != nil ? formatter.string(from: endDate!) : "Date not defined"
        
        let pointsStr = selectedPoints.map { "\($0.name) (\($0.timeOpening)-\($0.timeClosing))" }.joined(separator: ", ")
        
        let prompt = """
            You are an expert travel planner. Your task is to create a logical, well-paced daily itinerary for a trip to \(destination.isEmpty ? "an unknown destination" : destination) from \(startStr) to \(endStr).
            
            The user specifically wants to visit the following attractions (with their respective opening hours):
            \(pointsStr)
            
            CRITICAL RULES FOR THE ITINERARY:
            1. Geographic Logic: Group attractions that are located near each other on the same day to minimize travel time.
            2. Time Management: Respect the provided opening hours. Allocate realistic durations for each visit (e.g., 2-3 hours for a major museum, 1 hour for a viewpoint).
            3. Pacing: Distribute the selected attractions evenly across the available days. Do not overcrowd a single day.
            4. Breaks: Add generic, practical suggestions for "Lunch" and "Dinner" at appropriate times to make the itinerary complete.
            5. Language: All values for 'data', 'orario', 'luogo', and 'descrizione' MUST be written in English.
            
            JSON FORMATTING RULES:
            You must respond EXCLUSIVELY with a valid JSON array. Do not include markdown code blocks (like ```json), introductions, or conclusions. 
            Use exactly this schema:
            [
              {
                "data": "Day 1 - Monday, January 1",
                "attivita": [
                  {
                    "orario": "09:00 - 12:00",
                    "luogo": "Attraction Name",
                    "descrizione": "A brief, engaging description of what to do and why it is interesting."
                  },
                  {
                    "orario": "12:30 - 13:30",
                    "luogo": "Lunch Break",
                    "descrizione": "Time to rest and grab something to eat nearby."
                  }
                ]
              }
            ]
            """
        
        // Usa il modello Lite per l'itinerario
        let urlString = "https://generativelanguage.googleapis.com/v1beta/models/\(itineraryModel):generateContent?key=\(apiKey)"
        guard let url = URL(string: urlString) else {
            self.errorMessage = "Error: Invalid API URL."
            self.isLoading = false
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "contents": [["parts": [["text": prompt]]]],
            "generationConfig": ["responseMimeType": "application/json"]
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (data, response) = try await URLSession.shared.data(for: request)
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode != 200 {
                if httpResponse.statusCode == 503 {
                    // Messaggio ironico ma contestualizzato per l'errore 503 (Server sovraccarico)
                    self.errorMessage = "Oops! Too many people are planning their dream trip right now ✈️. Please wait a few seconds and try again!"
                } else {
                    // Gestione generica per altri errori
                    self.errorMessage = "Something went wrong (Error \(httpResponse.statusCode)). Please try again!"
                }
                
                self.isLoading = false
                return
            }
            
            if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
               let candidates = json["candidates"] as? [[String: Any]],
               let firstCandidate = candidates.first,
               let content = firstCandidate["content"] as? [String: Any],
               let parts = content["parts"] as? [[String: Any]],
               let firstPart = parts.first,
               let text = firstPart["text"] as? String {
                
                // Pulizia preventiva del testo nel caso l'IA ignori l'ordine di non usare il markdown
                var cleanText = text.trimmingCharacters(in: .whitespacesAndNewlines)
                if cleanText.hasPrefix("```json") { cleanText = String(cleanText.dropFirst(7)) }
                else if cleanText.hasPrefix("```") { cleanText = String(cleanText.dropFirst(3)) }
                if cleanText.hasSuffix("```") { cleanText = String(cleanText.dropLast(3)) }
                cleanText = cleanText.trimmingCharacters(in: .whitespacesAndNewlines)
                
                if let jsonData = cleanText.data(using: .utf8) {
                    let decoder = JSONDecoder()
                    let decodedDays = try decoder.decode([ItineraryDay].self, from: jsonData)
                    self.itineraryDays = decodedDays
                    self.saveCurrentTrip()
                } else {
                    self.errorMessage = "Error converting data."
                }
            } else {
                self.errorMessage = "Unexpected response format."
            }
        } catch {
            self.errorMessage = "Error: \(error.localizedDescription)"
        }
        
        self.isLoading = false
    }
    
    // MARK: - Recupero Prezzi Attrazioni in Batch
        func fetchAllPrices(for points: [IntrestPoint], destination: String) async {
            guard !points.isEmpty else { return }
            
            // 1. Salviamo le configurazioni necessarie per passarle ai task in background
            let currentApiKey = self.apiKey
            let currentModel = self.pricingModel
            
            // 2. Dividiamo l'array delle attrazioni in blocchi (chunk) da 5 elementi
            let chunkSize = 5
            let chunks = stride(from: 0, to: points.count, by: chunkSize).map {
                Array(points[$0..<min($0 + chunkSize, points.count)])
            }
            
            // 3. Eseguiamo le chiamate API in parallelo usando un TaskGroup
            await withTaskGroup(of: [String: String]?.self) { group in
                for chunk in chunks {
                    group.addTask {
                        // Usiamo un metodo statico per evitare di bloccare il MainActor
                        return await Self.fetchPricesForChunk(chunk, destination: destination, apiKey: currentApiKey, model: currentModel)
                    }
                }
                
                // 4. Aggiorniamo la UI progressivamente: non appena un gruppo da 5 finisce, i prezzi compaiono
                for await partialPrices in group {
                    if let prices = partialPrices {
                        for (key, value) in prices {
                            self.attractionPrices[key] = value
                        }
                    }
                }
            }
        }
        
        // MARK: - Helper per eseguire la singola chiamata su 5 elementi
        private static func fetchPricesForChunk(_ points: [IntrestPoint], destination: String, apiKey: String, model: String) async -> [String: String]? {
            let pointNames = points.map { $0.name }.joined(separator: ", ")
            
            let prompt = """
                    Find the approximate cost of a standard adult entry ticket for the following attractions in '\(destination)':
                    \(pointNames).
                    
                    Respond EXCLUSIVELY with a valid JSON file. The keys must be the exact names of the attractions and the values the price with the local currency symbol.
                    If you do not know the price of an attraction, use the string 'Costs not available'.
                    Example output:
                    {
                      "Trevi Fountain": "Free",
                      "Colosseum": "16 €"
                    }
                    """
            
            let urlString = "https://generativelanguage.googleapis.com/v1beta/models/\(model):generateContent?key=\(apiKey)"
            guard let url = URL(string: urlString) else { return nil }
            
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            
            let body: [String: Any] = [
                "contents": [["parts": [["text": prompt]]]],
                "tools": [
                    [
                        "googleSearch": [String: Any]()
                    ]
                ]
            ]
            
            do {
                request.httpBody = try JSONSerialization.data(withJSONObject: body)
                let (data, response) = try await URLSession.shared.data(for: request)
                
                if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode != 200 {
                    return nil
                }
                
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let candidates = json["candidates"] as? [[String: Any]],
                   let firstCandidate = candidates.first,
                   let content = firstCandidate["content"] as? [String: Any],
                   let parts = content["parts"] as? [[String: Any]],
                   let firstPart = parts.first,
                   let text = firstPart["text"] as? String {
                    
                    var cleanText = text.trimmingCharacters(in: .whitespacesAndNewlines)
                    if cleanText.hasPrefix("```json") { cleanText = String(cleanText.dropFirst(7)) }
                    else if cleanText.hasPrefix("```") { cleanText = String(cleanText.dropFirst(3)) }
                    if cleanText.hasSuffix("```") { cleanText = String(cleanText.dropLast(3)) }
                    cleanText = cleanText.trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    if let jsonData = cleanText.data(using: .utf8) {
                        return try JSONDecoder().decode([String: String].self, from: jsonData)
                    }
                }
            } catch {
                print("Errore fetch chunk prezzi: \(error.localizedDescription)")
            }
            
            return nil
        }
    
    // MARK: - Salvataggio Viaggio
    func saveCurrentTrip() {
        let newTrip = SavedTrip(
            destination: destination,
            startDate: startDate,
            endDate: endDate,
            itinerary: itineraryDays
        )
        savedTrips.append(newTrip)
        saveTripsToDevice() // Effettua il salvataggio sul dispositivo
    }
    
    // MARK: - Eliminazione Viaggio
    func deleteTrip(at offsets: IndexSet) {
        savedTrips.remove(atOffsets: offsets)
        saveTripsToDevice() // Aggiorna i dati salvati su UserDefaults
    }
}
