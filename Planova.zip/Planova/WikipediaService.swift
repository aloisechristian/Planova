import Foundation

class WikipediaService {
    
    static func fetchDetails(for title: String, in city: String) async throws -> WikipediaResponse {
        let deviceLanguage = Locale.current.language.languageCode?.identifier ?? "en"
        
        do {
            return try await performSmartSearch(languageCode: deviceLanguage, title: title, city: city)
        } catch {
            // Fallback in inglese se fallisce la lingua del dispositivo
            if deviceLanguage != "en" {
                print("⚠️ Pagina non trovata in \(deviceLanguage), provo in en...")
                return try await performSmartSearch(languageCode: "en", title: title, city: city)
            } else {
                throw error
            }
        }
    }
    
    private static func performSmartSearch(languageCode: String, title: String, city: String) async throws -> WikipediaResponse {
        
        // Pulizia della città (es. da "Bergen, Vestland" a "Bergen")
        let cleanCity = city.components(separatedBy: ",").first?.trimmingCharacters(in: .whitespaces) ?? city
        
        var bestMatchTitle: String? = nil
        
        // TENTATIVO 1: Ricerca con "Nome Attrazione + Città Pulita"
        let queryWithCity = "\(title) \(cleanCity)"
        bestMatchTitle = try await searchWikipediaTitle(query: queryWithCity, targetPOI: title, languageCode: languageCode)
        
        // TENTATIVO 2: Se fallisce, cerchiamo solo "Nome Attrazione"
        if bestMatchTitle == nil {
            print("⚠️ Nessun risultato affidabile per '\(queryWithCity)', provo solo con '\(title)'")
            bestMatchTitle = try await searchWikipediaTitle(query: title, targetPOI: title, languageCode: languageCode)
        }
        
        // Se non superiamo i filtri, lanciamo errore per mostrare la UI "Non trovato"
        guard let finalTitle = bestMatchTitle else {
            throw URLError(.resourceUnavailable)
        }
        
        // STEP FINALE: Scarichiamo il Summary
        let escapedTitle = finalTitle.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? finalTitle
        let summaryUrlString = "https://\(languageCode).wikipedia.org/api/rest_v1/page/summary/\(escapedTitle)"
        
        guard let summaryUrl = URL(string: summaryUrlString) else { throw URLError(.badURL) }
        
        // Creiamo la request con un User-Agent valido
        var summaryRequest = URLRequest(url: summaryUrl)
        summaryRequest.setValue("PlanovaApp/1.0 (studente@unina.it) iOS", forHTTPHeaderField: "User-Agent")
        
        let (summaryData, summaryResponse) = try await URLSession.shared.data(for: summaryRequest)
        
        guard let httpResponse = summaryResponse as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw URLError(.badServerResponse)
        }
        
        return try JSONDecoder().decode(WikipediaResponse.self, from: summaryData)
    }
    
    // Funzione di ricerca con VALIDAZIONE ANTI-FALSO POSITIVO
    private static func searchWikipediaTitle(query: String, targetPOI: String, languageCode: String) async throws -> String? {
        let escapedQuery = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let searchUrlString = "https://\(languageCode).wikipedia.org/w/api.php?action=query&list=search&srsearch=\(escapedQuery)&utf8=&format=json"
        
        guard let searchUrl = URL(string: searchUrlString) else { return nil }
        
        // Creiamo la request con un User-Agent valido
        var searchRequest = URLRequest(url: searchUrl)
        searchRequest.setValue("PlanovaApp/1.0 (studente@unina.it) iOS", forHTTPHeaderField: "User-Agent")
        
        let (searchData, _) = try await URLSession.shared.data(for: searchRequest)
        
        let searchResult = try JSONDecoder().decode(WikiSearchResponse.self, from: searchData)
        guard let firstResult = searchResult.query.search.first else { return nil }
        
        // --- FILTRO SEVERO ---
        // 1. Estrapoliamo le parole chiave dal nome originale (più lunghe di 3 lettere)
        let targetWords = targetPOI.lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { $0.count > 3 }
        
        let wikiTitle = firstResult.title.lowercased()
        var isRelevant = false
        
        // Se il nome è brevissimo saltiamo il filtro
        if targetWords.isEmpty {
            isRelevant = true
        } else {
            // 2. Controlliamo se almeno una radice (le prime 4 lettere) della parola originaria
            // è presente nel titolo di Wikipedia.
            // Usiamo il prefisso per bypassare differenze tipo "Colosseo" vs "Colosseum"
            for word in targetWords {
                let prefix = String(word.prefix(4))
                if wikiTitle.contains(prefix) {
                    isRelevant = true
                    break
                }
            }
        }
        
        if !isRelevant {
            print("🛑 Falso Positivo Bloccato! Cercavo: '\(targetPOI)' ma Wiki ha proposto: '\(firstResult.title)'")
            return nil
        }
        
        return firstResult.title
    }
}

// Strutture di supporto
struct WikiSearchResponse: Codable {
    let query: WikiQuery
}
struct WikiQuery: Codable {
    let search: [WikiSearchResult]
}
struct WikiSearchResult: Codable {
    let title: String
}
